#!/usr/bin/env bash
# 一键打安卓 APK
# 用法：
#   bash build_apk.sh                 -> 全架构通用包（兼容性最好）
#   bash build_apk.sh arm64           -> 只打 arm64-v8a（体积小一半，现代手机都支持）
#   bash build_apk.sh arm64 1.0.1 2   -> 指定版本号 / build 号
set -euo pipefail
cd "$(dirname "$0")"

ARCH="${1:-all}"
VERSION="${2:-1.0.0}"
BUILD_NUMBER="${3:-1}"

# 1. JDK 17：优先用 flet 自动装的，其次用 JAVA_HOME
if [ -z "${JAVA_HOME:-}" ] && ls -d "$HOME"/java/17* >/dev/null 2>&1; then
  export JAVA_HOME="$(ls -d "$HOME"/java/17* | head -1)"
fi

# 2. 国内镜像：storage.googleapis.com 下载 Flutter 只有几十 KB/s，必须换镜像
export FLUTTER_STORAGE_BASE_URL="${FLUTTER_STORAGE_BASE_URL:-https://storage.flutter-io.cn}"
export PUB_HOSTED_URL="${PUB_HOSTED_URL:-https://pub.flutter-io.cn}"

if ! command -v flet >/dev/null 2>&1; then
  echo "❌ 找不到 flet 命令，请先执行："
  echo "   python3 -m pip install -U 'flet[all]==1.1.2'"
  exit 1
fi

ARGS=(apk --yes --build-version "$VERSION" --build-number "$BUILD_NUMBER" --log-format plain)
if [ "$ARCH" = "arm64" ]; then
  ARGS+=(--arch arm64-v8a)
fi

# 3. 项目里的测试、文档、日志不需要打进 APK
ARGS+=(--exclude tests --exclude "*.log" --exclude "*.md" --exclude build_apk.sh --exclude assets/fonts)

echo "== 环境 =="
echo "Python: $(python3 --version)"
echo "JAVA_HOME: ${JAVA_HOME:-未设置（flet 会自动下载 JDK 17）}"
echo "Flutter 镜像: $FLUTTER_STORAGE_BASE_URL"
echo "版本号: ${VERSION} (build ${BUILD_NUMBER})  架构: ${ARCH}"
echo
echo "首次构建会自动下载 Flutter / JDK 17 / Android SDK（约 3-5 GB）。"
echo

flet build "${ARGS[@]}"

echo
echo "✅ 构建完成："
ls -lh build/apk/*.apk
