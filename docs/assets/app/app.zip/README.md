# 工程单位换算器

用 [Flet](https://flet.dev)（Python + Flutter）写的离线单位换算小工具，可打包成安卓 APK。

支持 10 类换算：

| 类别 | 单位 |
| --- | --- |
| 长度 | m、mm、cm、in、ft |
| 面积 | m²、mm²、cm²、in² |
| 质量 | kg、g、t、lb、oz |
| 力 | N、kN、kgf、lbf |
| 扭矩 | N·m、kgf·m、lbf·ft |
| 温度 | ℃、℉ |
| 热量 | BTU、kJ、kcal |
| 气体流量 | m³/h、L/min、CFM |
| 功率 | W、kW、PS、hp、BTU/h |
| 压强 | MPa、bar、kPa、kgf/cm²、psi |

## 运行

```bash
python3 -m pip install -U "flet==1.1.2"
flet run main.py
```

## 测试

```bash
python3 -m unittest discover -s tests -v
```

## 打包安卓 APK

```bash
bash build_apk.sh
# 或
flet build apk --yes
```

详细步骤、签名、常见报错见 [打包指南.md](打包指南.md)。

## iPhone / 网页版（PWA）

不装 Xcode、不用 Apple 账号也能在 iPhone 上用：构建成 Web 版，Safari「添加到主屏幕」。

```bash
flet build web --yes --no-cdn        # 生成 build/web
bash serve_web.sh                    # 同一 Wi-Fi 下用 iPhone Safari 打开打印的地址
```

公网访问：把 `build/web` 整个目录上传到 GitHub Pages / Cloudflare Pages / 对象存储等静态托管。
详见 [打包指南.md](打包指南.md) 第九节。
