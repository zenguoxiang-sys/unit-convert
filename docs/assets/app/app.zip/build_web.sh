#!/usr/bin/env bash
# 构建 Web / PWA 版本（iPhone 用）
# 用法：bash build_web.sh
set -euo pipefail
cd "$(dirname "$0")"

# 国内镜像：Flutter 产物、Dart 包都走镜像
export FLUTTER_STORAGE_BASE_URL="${FLUTTER_STORAGE_BASE_URL:-https://storage.flutter-io.cn}"
export PUB_HOSTED_URL="${PUB_HOSTED_URL:-https://pub.flutter-io.cn}"

# --no-cdn：CanvasKit / Pyodide 全部本地打包，不依赖 Google CDN（国内可用）
flet build web --yes --no-cdn \
  --pwa-short-name "单位换算" \
  --pwa-theme-color "#1565c0" \
  --pwa-background-color "#0b4f8a" \
  --build-version 1.0.0 --build-number 1 \
  --log-format plain

python3 patch_web.py

echo
echo "✅ Web 版构建完成：build/web"
echo "   本机预览：bash serve_web.sh"
echo "   部署：把 build/web 整个目录上传到静态托管即可"
