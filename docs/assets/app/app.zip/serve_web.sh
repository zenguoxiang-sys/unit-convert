#!/usr/bin/env bash
# 在局域网里把 Web 版跑起来，用 iPhone Safari 打开后“添加到主屏幕”
# 用法：bash serve_web.sh [端口]
set -euo pipefail
cd "$(dirname "$0")"

PORT="${1:-8899}"

if [ ! -d build/web ]; then
  echo "❌ 还没有 Web 构建产物，先执行："
  echo "   flet build web --yes --no-cdn"
  exit 1
fi

IP="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo 127.0.0.1)"

echo "=============================================="
echo " iPhone / iPad 用 Safari 打开："
echo "   http://${IP}:${PORT}"
echo
echo " 打开后点底部「分享」→「添加到主屏幕」"
echo " （Mac 和手机要在同一个 Wi-Fi，Mac 防火墙需允许 Python 入站）"
echo "=============================================="
echo "按 Ctrl+C 停止"
echo

cd build/web
exec python3 -m http.server "$PORT"
